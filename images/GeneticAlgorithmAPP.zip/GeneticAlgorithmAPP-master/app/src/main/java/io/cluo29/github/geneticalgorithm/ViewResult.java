package io.cluo29.github.geneticalgorithm;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import io.cluo29.github.geneticalgorithm.providers.Customer_Provider;
import io.cluo29.github.geneticalgorithm.providers.Item_Provider;
import io.cluo29.github.geneticalgorithm.providers.OrderRecord_Provider;
import io.cluo29.github.geneticalgorithm.server.Customer;
import io.cluo29.github.geneticalgorithm.server.GeneticAlgorithmTest;
import io.cluo29.github.geneticalgorithm.server.Item;


public class ViewResult extends AppCompatActivity {

    TextView textView8TV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewresult);
        textView8TV= (TextView) findViewById(R.id.textView8);

        int a1=getIntent().getIntExtra("a1",0);
        int a2=getIntent().getIntExtra("a2",0);
        int a3=getIntent().getIntExtra("a3",0);
        int a4=getIntent().getIntExtra("a4",0);
        int a5=getIntent().getIntExtra("a5",0);
        int a6=getIntent().getIntExtra("a6",0);
        int a7=getIntent().getIntExtra("a7",0);

        Item rec1 = Recommendation(a1,a2,a3,a4,a5,a6,a7);

        List<String> list = rec1.getItemString();

        String outPut = "";

        for (String i:list){
            outPut = outPut+i+", ";
        }

        textView8TV.setText(outPut);

    }

    public int countDifference(int a1, int a2, int a3, int a4, int a5, int a6, int a7,
                               int ha1, int ha2, int ha3, int ha4, int ha5, int ha6, int ha7){
        int result=0;
        if(a1!=ha1)
        {
            result=result+1;
        }
        if(a2!=ha2)
        {
            result=result+1;
        }
        if(a3!=ha3)
        {
            result=result+1;
        }
        if(a4!=ha4)
        {
            result=result+1;
        }
        if(a5!=ha5)
        {
            result=result+1;
        }
        if(a6!=ha6)
        {
            result=result+1;
        }
        if(a7!=ha7)
        {
            result=result+1;
        }
        return result;
    }


    public Item Recommendation(int a1, int a2, int a3, int a4, int a5, int a6, int a7){
        //read the target user


        //find n neibours
        int n = 10;

        List<Customer> list = new ArrayList<Customer>();

        Cursor cursor_app = getContentResolver().query(Customer_Provider.Customer_Data.CONTENT_URI, null, null, null,
                Customer_Provider.Customer_Data._ID + " DESC LIMIT 111");
        if (cursor_app.moveToFirst()) {
            do {

                int ha1 = cursor_app.getInt(cursor_app.getColumnIndex(Customer_Provider.Customer_Data.ATTRIBUTE1));
                int ha2 = cursor_app.getInt(cursor_app.getColumnIndex(Customer_Provider.Customer_Data.ATTRIBUTE2));
                int ha3 = cursor_app.getInt(cursor_app.getColumnIndex(Customer_Provider.Customer_Data.ATTRIBUTE3));
                int ha4 = cursor_app.getInt(cursor_app.getColumnIndex(Customer_Provider.Customer_Data.ATTRIBUTE4));
                int ha5 = cursor_app.getInt(cursor_app.getColumnIndex(Customer_Provider.Customer_Data.ATTRIBUTE5));
                int ha6 = cursor_app.getInt(cursor_app.getColumnIndex(Customer_Provider.Customer_Data.ATTRIBUTE6));
                int ha7 = cursor_app.getInt(cursor_app.getColumnIndex(Customer_Provider.Customer_Data.ATTRIBUTE7));

                Customer c1=new Customer();
                c1.attribute[0]=ha1;
                c1.attribute[1]=ha2;
                c1.attribute[2]=ha3;
                c1.attribute[3]=ha4;
                c1.attribute[4]=ha5;
                c1.attribute[5]=ha6;
                c1.attribute[6]=ha7;
                c1.customerID=cursor_app.getInt(cursor_app.getColumnIndex(Customer_Provider.Customer_Data.CUSTOMERID));
                c1.currentDifference = countDifference(a1,a2,a3,a4,a5,a6,a7,ha1,ha2,ha3,ha4,ha5,ha6,ha7);
                list.add(c1);

            } while (cursor_app.moveToNext());
        }
        if (cursor_app != null && !cursor_app.isClosed()) {
            cursor_app.close();
        }

        Collections.sort(list, new Comparator<Customer>() {
            @Override
            public int compare(Customer fruit1, Customer fruit2)
            {

                return  fruit1.currentDifference -fruit2.currentDifference;
            }
        });

        //get 10 of them
        List<Customer> listNeighbor = new ArrayList<Customer>();

        for(Customer i: list)
        {
            if(listNeighbor.size()<n) {
                listNeighbor.add(i);
            }
            else
            {
                break;
            }

        }

        List<Item> ItemNeighbor = new ArrayList<Item>();

        //look at what the 10 buy
        for(Customer i: listNeighbor) {
            int cid = i.customerID;
            Cursor cursor_app1 = getContentResolver().query(OrderRecord_Provider.OrderRecord_Data.CONTENT_URI, null,
                    OrderRecord_Provider.OrderRecord_Data.CUSTOMERID + "=" + cid
                    , null,
                    OrderRecord_Provider.OrderRecord_Data._ID + " DESC LIMIT 100");
            if (cursor_app1.moveToFirst()) {
                do {
                    int itemID = cursor_app1.getInt(cursor_app1.getColumnIndex(OrderRecord_Provider.OrderRecord_Data.ITEMID));
                    Cursor cursor_app2 = getContentResolver().query(Item_Provider.Item_Data.CONTENT_URI, null,
                            Item_Provider.Item_Data.ITEMID + "=" + itemID
                            , null,
                            Item_Provider.Item_Data._ID + " DESC LIMIT 1");
                    if (cursor_app2.moveToFirst()) {
                        Item item1=new Item();
                        item1.itemID=itemID;
                        item1.attribute[0] =cursor_app2.getInt(cursor_app2.getColumnIndex(Item_Provider.Item_Data.ATTRIBUTE1));
                        item1.attribute[1] =cursor_app2.getInt(cursor_app2.getColumnIndex(Item_Provider.Item_Data.ATTRIBUTE2));
                        item1.attribute[2] =cursor_app2.getInt(cursor_app2.getColumnIndex(Item_Provider.Item_Data.ATTRIBUTE3));
                        item1.attribute[3] =cursor_app2.getInt(cursor_app2.getColumnIndex(Item_Provider.Item_Data.ATTRIBUTE4));
                        item1.attribute[4] =cursor_app2.getInt(cursor_app2.getColumnIndex(Item_Provider.Item_Data.ATTRIBUTE5));
                        item1.attribute[5] =cursor_app2.getInt(cursor_app2.getColumnIndex(Item_Provider.Item_Data.ATTRIBUTE6));
                        ItemNeighbor.add(item1);
                    }
                    if (cursor_app2 != null && !cursor_app2.isClosed()) {
                        cursor_app2.close();
                    }

                } while (cursor_app1.moveToNext());
            }
            if (cursor_app1 != null && !cursor_app1.isClosed()) {
                cursor_app1.close();
            }
        }

        //run genetic

        //count gene in ItemNeighbor as evaluation function

        GeneticAlgorithmTest test = new GeneticAlgorithmTest(ItemNeighbor);
        test.calculate();

        //the recommendation
        return test.getX();


    }


}

package io.cluo29.github.geneticalgorithm.server;



import java.util.ArrayList;
import java.util.List;

public class Chromosome {
    public boolean[] gene;//基因序列   8bits per attribute,  256 space, NumAttri attributes, 48 bits

    //8 bits, so int 32bits is enough

    public double score;// evaluation function得分

    public final int bits=8;

    public final int NumAttri=6;

    public final int[] NumAttriEle={4,5,5,4,5,3};

    //f1职业装风格偏好={经典时尚、自然休闲、都市运动、未来前卫}
    //材料分类={棉、麻、毛料、丝绸、涤纶}
    //色彩分类={核心色、红色、黄色、蓝色、浅粉色}
    //工艺分类={免烫、速干、防静电、防辐射}
    //图案分类={纯色、条纹、格纹、定位印花、满地印花}
    //f6装饰细节={荷叶边、刺绣、蕾丝}

    public Chromosome(boolean[] array)
    {
        gene= new boolean[array.length];
        gene= array.clone();
    }

    public Chromosome(int size) //size = bits*NumAttri
    {
        initGeneSize(size);
        for (int i =0; i<size;i++)
        {
            gene[i] = Math.random() >=0.5;
        }
    }

    public Chromosome()
    {

    }


    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }


    private void initGeneSize(int size){
        if (size<=0){
            return;
        }
        gene = new boolean[size];
    }

    public static Chromosome clone(final Chromosome c){
        if (c == null || c.gene == null) {
            return null;
        }
        Chromosome copy = new Chromosome();
        copy.initGeneSize(c.gene.length);
        for (int i = 0; i < c.gene.length; i++) {
            copy.gene[i] = c.gene[i];
        }
        return copy;
    }

    public static List<Chromosome> genetic(Chromosome p1, Chromosome p2) {
        if (p1 == null || p2 == null) { //染色体有一个为空，不产生下一代
            return null;
        }
        if (p1.gene == null || p2.gene == null) { //染色体有一个没有基因序列，不产生下一代
            return null;
        }
        if (p1.gene.length != p2.gene.length) { //染色体基因序列长度不同，不产生下一代
            return null;
        }
        Chromosome c1 = clone(p1);
        Chromosome c2 = clone(p2);
        //随机产生交叉互换位置
        int size = c1.gene.length;
        int a = ((int) (Math.random() * size)) % size;
        int b = ((int) (Math.random() * size)) % size;
        int min = a > b ? b : a;
        int max = a > b ? a : b;
        //对位置上的基因进行交叉互换
        for (int i = min; i <= max; i++) {
            boolean t = c1.gene[i];
            c1.gene[i] = c2.gene[i];
            c2.gene[i] = t;
        }
        List<Chromosome> list = new ArrayList<Chromosome>();
        list.add(c1);
        list.add(c2);
        return list;
    }

    //基因num个位置发生变异
    public void mutation(int num) {
        //允许变异
        int size = gene.length;
        for (int i = 0; i < num; i++) {
            //寻找变异位置
            int at = ((int) (Math.random() * size)) % size;
            //变异后的值
            boolean bool = !gene[at];
            gene[at] = bool;
        }
    }

    public Item getItem(){

        Item item1 = new Item();

        for(int i=0;i<NumAttri;i++)
        {
            item1.attribute[i]=getAttri(i);
        }

        return item1;
    }


    public int getAttri(int number)
    {
        int attriInt = getAttriInt(number);
        int value = attriInt % NumAttriEle[number];
        return value;
    }

    public int getAttriInt(int number)
    {
        //if bits ==8
        //0 means 0-7
        //1 means 8-15
        boolean[] binAttri = new boolean [bits];
        for(int i=0;i<bits;i++)
        {
            binAttri[i]=gene[number*bits+i];
        }
        return booleansToInt(binAttri);
    }

    static int booleansToInt(boolean[] arr){
        int n = 0;
        for (boolean b : arr)
            n = (n << 1) | (b ? 1 : 0);
        return n;
    }
}

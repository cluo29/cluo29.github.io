package io.cluo29.github.geneticalgorithm.server;

import android.util.Log;

import java.util.ArrayList;
import java.util.List;




public class GeneticAlgorithmTest extends GeneticAlgorithm{


    List<Item> ItemNeighbor;

    public GeneticAlgorithmTest(List<Item> ItemNeighbor1) {
        super(48);
        ItemNeighbor = new ArrayList<>(ItemNeighbor1);
    }

    @Override
    public Item changeX(Chromosome chro) {

        return chro.getItem();
    }

    @Override
    public double caculateY(Item x) {

        double result = 0d;

        //Log.d("CJJ","GAT33");

        for(Item i: ItemNeighbor) {

            if(x.attribute[0]==i.attribute[0]&&
                    x.attribute[1]==i.attribute[1]&&
                    x.attribute[2]==i.attribute[2]&&
                    x.attribute[3]==i.attribute[3]&&
                    x.attribute[4]==i.attribute[4]&&
                    x.attribute[5]==i.attribute[5])
            {
                result=result+1;
            }

            //Log.d("CJJ",""+i.itemID);
        }

        return result;
    }

    /* usage example
    public static void main(String[] args) {
        GeneticAlgorithmTest test = new GeneticAlgorithmTest();
        test.caculte();
    }*/
}

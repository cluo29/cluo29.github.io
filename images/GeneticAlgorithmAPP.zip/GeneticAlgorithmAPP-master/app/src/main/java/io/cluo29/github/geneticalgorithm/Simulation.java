package io.cluo29.github.geneticalgorithm;

import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.IBinder;
import android.util.Log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import io.cluo29.github.geneticalgorithm.providers.Customer_Provider.Customer_Data;

import io.cluo29.github.geneticalgorithm.providers.Item_Provider.Item_Data;

import io.cluo29.github.geneticalgorithm.providers.OrderRecord_Provider.OrderRecord_Data;
import io.cluo29.github.geneticalgorithm.server.Chromosome;
import io.cluo29.github.geneticalgorithm.server.Customer;
import io.cluo29.github.geneticalgorithm.server.GeneticAlgorithmTest;
import io.cluo29.github.geneticalgorithm.server.Item;

public class Simulation extends Service {


    @Override
    public void onCreate() {

        //if no data yet, add
        Cursor cursor_app = getContentResolver().query(Customer_Data.CONTENT_URI, null, null, null,
                Customer_Data._ID + " DESC LIMIT 1");
        int number = cursor_app.getCount();
        if (cursor_app != null && cursor_app.moveToFirst()) {

        }
        if (cursor_app != null && !cursor_app.isClosed()) {

            cursor_app.close();
        }
        if(number==0) {
            //create 100 users

            for(int id=0; id<100; id++){
                int a1=getRandom(0,1);
                int a2=getRandom(0,3);
                int a3=getRandom(0,4);
                int a4=getRandom(0,4);
                int a5=getRandom(0,4);
                int a6=getRandom(0,4);
                int a7=getRandom(0,4);

                //Log.d("CJJ",""+getRandom(0,4));
                createUser(id,a1,a2,a3,a4,a5,a6,a7);
            }

            //create enough items
            //6000 possible states
            int iid = 0;

            for(int a1=0;a1<4;a1++)
            {
                for(int a2=0;a2<5;a2++)
                {
                    for(int a3=0;a3<5;a3++)
                    {
                        for(int a4=0;a4<4;a4++)
                        {
                            for(int a5=0;a5<5;a5++)
                            {
                                for(int a6=0;a6<3;a6++)
                                {
                                    createItem(iid,a1,a2,a3,a4,a5,a6);
                                    iid++;
                                }
                            }
                        }
                    }
                }
            }
            Log.d("CJJ","84");
            //simu purchase

            simulationPurchase();

        }
        Log.d("CJJ","90");
        //simulationRecommendation();

    }

    //create a user
    public void createUser (int id, int a1, int a2, int a3, int a4, int a5, int a6, int a7){

        ContentValues rowData = new ContentValues();

        rowData.put(Customer_Data.ATTRIBUTE1, a1);
        rowData.put(Customer_Data.ATTRIBUTE2, a2);
        rowData.put(Customer_Data.ATTRIBUTE3, a3);
        rowData.put(Customer_Data.ATTRIBUTE4, a4);
        rowData.put(Customer_Data.ATTRIBUTE5, a5);
        rowData.put(Customer_Data.ATTRIBUTE6, a6);
        rowData.put(Customer_Data.ATTRIBUTE7, a7);
        rowData.put(Customer_Data.CUSTOMERID, id);
        getApplicationContext().getContentResolver().insert(Customer_Data.CONTENT_URI, rowData);
    }

    public void createItem (int id, int a1, int a2, int a3, int a4, int a5, int a6){

        ContentValues rowData = new ContentValues();

        rowData.put(Item_Data.ATTRIBUTE1, a1);
        rowData.put(Item_Data.ATTRIBUTE2, a2);
        rowData.put(Item_Data.ATTRIBUTE3, a3);
        rowData.put(Item_Data.ATTRIBUTE4, a4);
        rowData.put(Item_Data.ATTRIBUTE5, a5);
        rowData.put(Item_Data.ATTRIBUTE6, a6);
        rowData.put(Item_Data.ITEMID, id);
        getApplicationContext().getContentResolver().insert(Item_Data.CONTENT_URI, rowData);

    }

    public void createOrder (int cid, int iid, int quan){

        ContentValues rowData = new ContentValues();

        rowData.put(OrderRecord_Data.CUSTOMERID, cid);
        rowData.put(OrderRecord_Data.ITEMID, iid);
        rowData.put(OrderRecord_Data.QUANTITY, quan);
        getApplicationContext().getContentResolver().insert(OrderRecord_Data.CONTENT_URI, rowData);

    }

    //purchase a certain item with feature values
    public void purchaseByAttri(int cid, int quan, int a1, int a2, int a3, int a4, int a5, int a6){
        //search item id with a1-a6
        Cursor cursor_app = getContentResolver().query(Item_Data.CONTENT_URI, null,
                Item_Data.ATTRIBUTE1+"="+a1+" AND "+
                        Item_Data.ATTRIBUTE2+"="+a2+" AND "+
                        Item_Data.ATTRIBUTE3+"="+a3+" AND "+
                        Item_Data.ATTRIBUTE4+"="+a4+" AND "+
                        Item_Data.ATTRIBUTE5+"="+a5+" AND "+
                        Item_Data.ATTRIBUTE6+"="+a6, null,
                Item_Data._ID + " DESC LIMIT 1");

        if (cursor_app != null && cursor_app.moveToFirst()) {
            int itemID = cursor_app.getInt(cursor_app.getColumnIndex(Item_Data.ITEMID));
            createOrder(cid, itemID, quan);
        }
        if (cursor_app != null && !cursor_app.isClosed()) {
            cursor_app.close();
        }
    }

    public void simulationPurchase(){
        //get every user
        Cursor cursor_app = getContentResolver().query(Customer_Data.CONTENT_URI, null, null, null, Customer_Data._ID + " DESC LIMIT 111");
        if (cursor_app.moveToFirst()) {
            do {
                //get user id
                int cid = cursor_app.getInt(cursor_app.getColumnIndex(Customer_Data.CUSTOMERID));
                //user attri 1

                //buy random
                {
                    int ia1 = getRandom(0, 3);
                    int ia2 = getRandom(0, 4);
                    int ia3 = getRandom(0, 4);
                    int ia4 = getRandom(0, 3);
                    int ia5 = getRandom(0, 4);
                    int ia6 = getRandom(0, 2);

                    purchaseByAttri(cid, 1, ia1, ia2, ia3, ia4, ia5, ia6);
                }

                //buy random again
                {
                    int ia1 = getRandom(0, 3);
                    int ia2 = getRandom(0, 4);
                    int ia3 = getRandom(0, 4);
                    int ia4 = getRandom(0, 3);
                    int ia5 = getRandom(0, 4);
                    int ia6 = getRandom(0, 2);

                    purchaseByAttri(cid, 1, ia1, ia2, ia3, ia4, ia5, ia6);
                }

                //3rd time
                {
                    int ia1 = getRandom(0, 3);
                    int ia2 = getRandom(0, 4);
                    int ia3 = getRandom(0, 4);
                    int ia4 = getRandom(0, 3);
                    int ia5 = getRandom(0, 4);
                    int ia6 = getRandom(0, 2);

                    purchaseByAttri(cid, 1, ia1, ia2, ia3, ia4, ia5, ia6);
                }


            } while (cursor_app.moveToNext());
        }
        if (cursor_app != null && !cursor_app.isClosed()) {
            cursor_app.close();
        }

    }



    @Override
    public IBinder onBind(Intent intent) {
        // We don't provide binding, so return null
        return null;
    }

    public static int getRandom(int min, int max) //inclusive bounds
    {
        Double tmp= (Math.random()*(max+1-min))+min;
        return tmp.intValue();
    }

}

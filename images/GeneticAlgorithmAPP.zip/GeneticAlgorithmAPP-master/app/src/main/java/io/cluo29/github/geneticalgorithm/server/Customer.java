package io.cluo29.github.geneticalgorithm.server;

import java.util.ArrayList;
import java.util.List;
public class Customer {

    public int[] attribute;

    public int customerID;

    public int currentDifference;

    public Customer(){
        attribute= new int[7]; //f1-7, needs init
        //customerID = ID;
    }

    public List<String> getCustomerString()
    {
        List<String> list = new ArrayList<String>();

        switch (attribute[0]){//性别={男性、女性}
            case 0:
                list.add("男性");
                break;
            case 1:
                list.add("女性");
                break;
        }
        switch (attribute[1]){//年龄={18-25岁、26-35岁、36-45岁、46-55岁}
            case 0:
                list.add("18-25岁");
                break;
            case 1:
                list.add("26-35岁");
                break;
            case 2:
                list.add("36-45岁");
                break;
            case 3:
                list.add("46-55岁");
                break;
        }
        //受教育程度={高中以下、高职高专、本科大专、硕士、博士及以上}
        switch (attribute[2]){
            case 0:
                list.add("高中以下");
                break;
            case 1:
                list.add("高职高专");
                break;
            case 2:
                list.add("本科大专");
                break;
            case 3:
                list.add("硕士");
                break;
            case 4:
                list.add("博士及以上");
                break;
        }
        //职业={金融业、教育业、餐饮业、交通业、服务业}
        switch (attribute[3]){
            case 0:
                list.add("金融业");
                break;
            case 1:
                list.add("教育业");
                break;
            case 2:
                list.add("餐饮业");
                break;
            case 3:
                list.add("交通业");
                break;
            case 4:
                list.add("服务业");
                break;
        }
        //性格特征={严谨性、随和性、开放性、外倾性、神经质}
        switch (attribute[4]){
            case 0:
                list.add("严谨性");
                break;
            case 1:
                list.add("随和性");
                break;
            case 2:
                list.add("开放性");
                break;
            case 3:
                list.add("外倾性");
                break;
            case 4:
                list.add("神经质");
                break;
        }

        //生活区域={华北地区、东北地区、华东地区、东南地区、西部地区}
        switch (attribute[5]){
            case 0:
                list.add("华北地区");
                break;
            case 1:
                list.add("东北地区");
                break;
            case 2:
                list.add("华东地区");
                break;
            case 3:
                list.add("东南地区");
                break;
            case 4:
                list.add("西部地区");
                break;
        }

        //每月可支配金额={1,000以下，1,000-3,000，3,000~6,000，6,000~10,000，10,000以上}
        switch (attribute[6]){
            case 0:
                list.add("华北地区");
                break;
            case 1:
                list.add("东北地区");
                break;
            case 2:
                list.add("华东地区");
                break;
            case 3:
                list.add("东南地区");
                break;
            case 4:
                list.add("西部地区");
                break;
        }
        return list;
    }
}

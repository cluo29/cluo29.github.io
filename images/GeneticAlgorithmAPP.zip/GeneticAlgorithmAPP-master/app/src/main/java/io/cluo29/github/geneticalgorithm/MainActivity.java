package io.cluo29.github.geneticalgorithm;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    private RadioGroup radioGroup1;
    private RadioGroup radioGroup2;
    private RadioGroup radioGroup3;
    private RadioGroup radioGroup4;
    private RadioGroup radioGroup5;
    private RadioGroup radioGroup6;
    private RadioGroup radioGroup7;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startService(new Intent(this, Simulation.class));

        radioGroup1 = (RadioGroup) findViewById(R.id.radio1);
        radioGroup2 = (RadioGroup) findViewById(R.id.radio2);
        radioGroup3 = (RadioGroup) findViewById(R.id.radio3);
        radioGroup4 = (RadioGroup) findViewById(R.id.radio4);
        radioGroup5 = (RadioGroup) findViewById(R.id.radio5);
        radioGroup6 = (RadioGroup) findViewById(R.id.radio6);
        radioGroup7 = (RadioGroup) findViewById(R.id.radio7);

        Button nextButton = (Button) findViewById(R.id.button);

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedId1 = radioGroup1.getCheckedRadioButtonId();
                int a1=0;
                int a2=0;
                int a3=0;
                int a4=0;
                int a5=0;
                int a6=0;
                int a7=0;
                switch(selectedId1){
                    case R.id.radio1a:

                        break;
                    case R.id.radio1b:
                        a1=1;
                        break;
                }

                int selectedId2 = radioGroup2.getCheckedRadioButtonId();
                switch(selectedId2){
                    case R.id.radio2a:
                        //Log.d("CJJ","radio2a");
                        break;
                    case R.id.radio2b:
                        a2=1;
                        break;
                    case R.id.radio2c:
                        a2=2;
                        break;
                    case R.id.radio2d:
                        a2=3;
                        break;
                }
                int selectedId3 = radioGroup3.getCheckedRadioButtonId();
                switch(selectedId3){
                    case R.id.radio3a:

                        break;
                    case R.id.radio3b:
                        a3=1;
                        break;
                    case R.id.radio3c:
                        a3=2;
                        break;
                    case R.id.radio3d:
                        a3=3;
                        break;
                    case R.id.radio3e:
                        a3=4;
                        break;
                }
                int selectedId4 = radioGroup4.getCheckedRadioButtonId();
                switch(selectedId4){
                    case R.id.radio4a:

                        break;
                    case R.id.radio4b:
                        a4=1;
                        break;
                    case R.id.radio4c:
                        a4=2;
                        break;
                    case R.id.radio4d:
                        a4=3;
                        break;
                    case R.id.radio4e:
                        a4=4;
                        break;
                }
                int selectedId5 = radioGroup5.getCheckedRadioButtonId();
                switch(selectedId5){
                    case R.id.radio5a:

                        break;
                    case R.id.radio5b:
                        a5=1;
                        break;
                    case R.id.radio5c:
                        a5=2;
                        break;
                    case R.id.radio5d:
                        a5=3;
                        break;
                    case R.id.radio5e:
                        a5=4;
                        break;
                }
                int selectedId6 = radioGroup6.getCheckedRadioButtonId();
                switch(selectedId6){
                    case R.id.radio6a:

                        break;
                    case R.id.radio6b:
                        a6=1;
                        break;
                    case R.id.radio6c:
                        a6=2;
                        break;
                    case R.id.radio6d:
                        a6=3;
                        break;
                    case R.id.radio6e:
                        a6=4;
                        break;
                }
                int selectedId7 = radioGroup7.getCheckedRadioButtonId();
                switch(selectedId7){
                    case R.id.radio7a:

                        break;
                    case R.id.radio7b:
                        a7=1;
                        break;
                    case R.id.radio7c:
                        a7=2;
                        break;
                    case R.id.radio7d:
                        a7=3;
                        break;
                    case R.id.radio7e:
                        a7=4;
                        break;
                }

                Intent i = new Intent( getApplicationContext(), ViewResult.class);
                i.putExtra("a1",a1);
                i.putExtra("a2",a2);
                i.putExtra("a3",a3);
                i.putExtra("a4",a4);
                i.putExtra("a5",a5);
                i.putExtra("a6",a6);
                i.putExtra("a7",a7);
                startActivity(i);
            }
        });


    }
}

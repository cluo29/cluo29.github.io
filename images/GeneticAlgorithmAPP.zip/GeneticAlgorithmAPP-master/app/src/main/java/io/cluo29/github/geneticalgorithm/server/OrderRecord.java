package io.cluo29.github.geneticalgorithm.server;



public class OrderRecord {

    public int customerID;
    public int ItemID;
    public int quantity;
    public int OrderRecordID;

    public OrderRecord(int cID, int iID, int quan){
        customerID=cID;
        ItemID=iID;
        quantity=quan;
    }
}

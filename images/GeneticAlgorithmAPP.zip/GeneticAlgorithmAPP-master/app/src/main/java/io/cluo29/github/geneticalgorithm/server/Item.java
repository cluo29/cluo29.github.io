package io.cluo29.github.geneticalgorithm.server;


import java.util.ArrayList;
import java.util.List;
public class Item {

    public int[] attribute;

    public int itemID;

    public Item(){
        attribute= new int[6]; //f1-6, needs init

    }

    public List<String> getItemString()
    {
        List<String> list = new ArrayList<String>();

        switch (attribute[0]){
            case 0:
                list.add("经典时尚");
                break;
            case 1:
                list.add("自然休闲");
                break;
            case 2:
                list.add("都市运动");
                break;
            case 3:
                list.add("未来前卫");
                break;
        }
        switch (attribute[1]){
            case 0:
                list.add("棉");
                break;
            case 1:
                list.add("麻");
                break;
            case 2:
                list.add("毛料");
                break;
            case 3:
                list.add("丝绸");
                break;
            case 4:
                list.add("涤纶");
                break;
        }
        switch (attribute[2]){
            case 0:
                list.add("核心色");
                break;
            case 1:
                list.add("红色");
                break;
            case 2:
                list.add("黄色");
                break;
            case 3:
                list.add("蓝色");
                break;
            case 4:
                list.add("浅粉色");
                break;
        }
        switch (attribute[3]){
            case 0:
                list.add("免烫");
                break;
            case 1:
                list.add("速干");
                break;
            case 2:
                list.add("防静电");
                break;
            case 3:
                list.add("防辐射");
                break;
        }
        switch (attribute[4]){
            case 0:
                list.add("纯色");
                break;
            case 1:
                list.add("条纹");
                break;
            case 2:
                list.add("格纹");
                break;
            case 3:
                list.add("定位印花");
                break;
            case 4:
                list.add("满地印花");
                break;
        }
        switch (attribute[5]){
            case 0:
                list.add("荷叶边");
                break;
            case 1:
                list.add("刺绣");
                break;
            case 2:
                list.add("蕾丝");
                break;
        }
        return list;
    }
}
//商品属性
//f1, 职业装风格偏好={0.经典时尚、1.自然休闲、2.都市运动、3.未来前卫}
//f2材料分类={棉、麻、毛料、丝绸、涤纶}
//f3色彩分类={核心色、红色、黄色、蓝色、浅粉色}
//f4工艺分类={免烫、速干、防静电、防辐射}
//f5图案分类={纯色、条纹、格纹、定位印花、满地印花}
//f6装饰细节={荷叶边、刺绣、蕾丝}